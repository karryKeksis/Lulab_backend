module.exports = {
  Date: require('./scalars/date'), // eslint-disable-line
};

