'use strict';

const ResolverHelper = require("../common/resolverHelper");

const CONNECTOR_NAME = 'courseClassification';
const MODEL_NAME = 'CourseClassification';

module.exports = {
  Query: {
    queryCourseClassification(root, {
      option
    }, ctx) {
      return ctx.connector[CONNECTOR_NAME].queryCourseClassification(option);
      //var temp =  ResolverHelper.fetchById("", ctx, CONNECTOR_NAME, MODEL_NAME);
      // return temp
    },
  }
};
